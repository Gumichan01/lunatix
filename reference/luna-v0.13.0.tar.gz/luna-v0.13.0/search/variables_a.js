var searchData=
[
  ['major',['major',['../struct_l_x___version_info_1_1_l_x___version.html#a6d46fde739a1ef756a5d23ac08916d62',1,'LX_VersionInfo::LX_Version']]],
  ['major_5fversion',['MAJOR_VERSION',['../namespace_l_x___graphics_1_1_l_x___open_g_l.html#a678db8893f8cc1b8082db9c9d539ab45',1,'LX_Graphics::LX_OpenGL']]],
  ['minor',['minor',['../struct_l_x___version_info_1_1_l_x___version.html#a2e7dda243b964f917303a8e1d2f78d70',1,'LX_VersionInfo::LX_Version']]],
  ['minor_5fversion',['MINOR_VERSION',['../namespace_l_x___graphics_1_1_l_x___open_g_l.html#a1cccf419c1d5256853f4c0dfc6fa0167',1,'LX_Graphics::LX_OpenGL']]]
];
