var searchData=
[
  ['r',['r',['../struct_l_x__gl_colour.html#ab9285afc64fbd3b92f722eb9d05d0675',1,'LX_glColour']]],
  ['radius',['radius',['../struct_l_x___physics_1_1_l_x___circle.html#aaa9e90268010fc1ddea47439b0f97ca9',1,'LX_Physics::LX_Circle']]],
  ['refresh_5frate',['refresh_rate',['../struct_l_x___system_info_1_1_l_x___display_mode.html#a1bcd047299a07537fd909dc333bd6588',1,'LX_SystemInfo::LX_DisplayMode']]],
  ['rev_5fstereo',['rev_stereo',['../struct_l_x___mixer_1_1_l_x___mixer_effect.html#a3b51ab24b8e436d4e75007cd6af8f04c',1,'LX_Mixer::LX_MixerEffect']]],
  ['reverse_5fstereo',['reverse_stereo',['../struct_l_x___mixer_1_1_l_x___mixer_effect_type.html#ab364a4ff6cf6cf201700bcfe7b2a07ea',1,'LX_Mixer::LX_MixerEffectType']]]
];
