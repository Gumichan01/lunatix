var searchData=
[
  ['fullscreen',['FULLSCREEN',['../namespace_l_x___win.html#a8047b0ab777e4412a0d01a12606beb70ab89c3d897b196ffff1537331bc659a97',1,'LX_Win']]],
  ['fullscreen_5fdesktop',['FULLSCREEN_DESKTOP',['../namespace_l_x___win.html#a8047b0ab777e4412a0d01a12606beb70a00e9544e1dc7219fca1faff976335f48',1,'LX_Win']]]
];
