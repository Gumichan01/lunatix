var searchData=
[
  ['bgr555',['BGR555',['../namespace_l_x___graphics.html#af0a27c09ff9fc101b99d3509ce162e7fa496707ae7bc992cb55f9ce3f2d95b759',1,'LX_Graphics']]],
  ['bgr565',['BGR565',['../namespace_l_x___graphics.html#af0a27c09ff9fc101b99d3509ce162e7fa7c93b8aa81bd858a70f2e6a55f59b68d',1,'LX_Graphics']]],
  ['bgr888',['BGR888',['../namespace_l_x___graphics.html#af0a27c09ff9fc101b99d3509ce162e7fa7cec9e9c2dffb6982c75cdbf5f2af9ef',1,'LX_Graphics']]],
  ['bgra4444',['BGRA4444',['../namespace_l_x___graphics.html#af0a27c09ff9fc101b99d3509ce162e7fa947c44b1aedaed558e03b2885a550bf7',1,'LX_Graphics']]],
  ['bgra5551',['BGRA5551',['../namespace_l_x___graphics.html#af0a27c09ff9fc101b99d3509ce162e7fa827fa748e9b9fd829c528ce04069f0af',1,'LX_Graphics']]],
  ['bgra8888',['BGRA8888',['../namespace_l_x___graphics.html#af0a27c09ff9fc101b99d3509ce162e7fa0ec600bfbcf9efd33a5d337700f19896',1,'LX_Graphics']]],
  ['bgrx8888',['BGRX8888',['../namespace_l_x___graphics.html#af0a27c09ff9fc101b99d3509ce162e7fab5dbc9955a7992b2f2b4986c8f09afe9',1,'LX_Graphics']]],
  ['borderless',['BORDERLESS',['../namespace_l_x___win.html#a8047b0ab777e4412a0d01a12606beb70af744a3ac16b1ac0bc9df0aa02cc1a038',1,'LX_Win']]]
];
