var searchData=
[
  ['name',['name',['../struct_l_x___device_1_1_l_x___gamepad_info.html#a997a7102b615f437f33b18101af41c3a',1,'LX_Device::LX_GamepadInfo']]],
  ['nb_5faxis',['nb_axis',['../struct_l_x___device_1_1_l_x___gamepad_info.html#a75180bab78f954ff936fd3808d093c57',1,'LX_Device::LX_GamepadInfo']]],
  ['nb_5fballs',['nb_balls',['../struct_l_x___device_1_1_l_x___gamepad_info.html#a11e4f0fd5d3ee299b3e6810dc39b4ef0',1,'LX_Device::LX_GamepadInfo']]],
  ['nb_5fbuttons',['nb_buttons',['../struct_l_x___device_1_1_l_x___gamepad_info.html#afeb2d52beda8098d527ef2ba64aa950f',1,'LX_Device::LX_GamepadInfo']]],
  ['nb_5fhats',['nb_hats',['../struct_l_x___device_1_1_l_x___gamepad_info.html#a01671b40005098668b482821cd1c22f2',1,'LX_Device::LX_GamepadInfo']]],
  ['npos',['npos',['../class_u_t_f8string.html#aabee38fa7aa9a4ee98985252a4d90114',1,'UTF8string']]]
];
