var searchData=
[
  ['tag',['Tag',['../classlibtagpp_1_1_tag.html',1,'libtagpp']]]
];
