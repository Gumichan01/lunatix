var searchData=
[
  ['nbactiveparticles',['nbActiveParticles',['../class_l_x___particle_engine_1_1_l_x___particle_system.html#a5fb98564804f85c1b02e771c5371ff96',1,'LX_ParticleEngine::LX_ParticleSystem']]],
  ['nbemptyparticles',['nbEmptyParticles',['../class_l_x___particle_engine_1_1_l_x___particle_system.html#a352d00123cb2ac45b9f1a286edea0747',1,'LX_ParticleEngine::LX_ParticleSystem']]],
  ['nbtotalparticles',['nbTotalParticles',['../class_l_x___particle_engine_1_1_l_x___particle_system.html#a3e292f638e7a3c84fd76ec791abae22b',1,'LX_ParticleEngine::LX_ParticleSystem']]],
  ['nbwindows',['nbWindows',['../class_l_x___win_1_1_l_x___window_manager.html#a6a9a83f620dd2a24382752689826e0f0',1,'LX_Win::LX_WindowManager']]],
  ['neweffect',['newEffect',['../class_l_x___device_1_1_l_x___haptic.html#a822557351d6eaf789fdace9fa7730054',1,'LX_Device::LX_Haptic']]],
  ['normalize',['normalize',['../namespace_l_x___physics.html#ab9ad44483e91a68eab83ff5adf211069',1,'LX_Physics']]],
  ['numberofdevices',['numberOfDevices',['../namespace_l_x___device.html#a8721783180d0db4c014fdcb5933d6fa2',1,'LX_Device']]],
  ['numberofedges',['numberOfEdges',['../class_l_x___physics_1_1_l_x___polygon.html#a17e0eb3dc136665ca7988e959c98ecaf',1,'LX_Physics::LX_Polygon']]],
  ['numberofeffects',['numberOfEffects',['../class_l_x___device_1_1_l_x___haptic.html#a4847c88b76fd27c168781d06724f29c6',1,'LX_Device::LX_Haptic']]],
  ['numberofhapticdevices',['numberOfHapticDevices',['../namespace_l_x___device.html#a21019abb37285fcd7b90e0b490a6664a',1,'LX_Device']]]
];
