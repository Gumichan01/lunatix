var searchData=
[
  ['patch',['patch',['../struct_l_x___version_info_1_1_l_x___version.html#a4b9888a207ed8c68b75ad6642c1c854f',1,'LX_VersionInfo::LX_Version']]]
];
