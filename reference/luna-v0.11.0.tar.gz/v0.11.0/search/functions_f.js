var searchData=
[
  ['read',['read',['../class_l_x___file_i_o_1_1_l_x___abstract_file.html#a2371a5f1e7653d39827b6b81ce1d0915',1,'LX_FileIO::LX_AbstractFile::read()'],['../class_l_x___file_i_o_1_1_l_x___file.html#a03902a7c6b7a401d241f663e44e80666',1,'LX_FileIO::LX_File::read()'],['../class_l_x___file_i_o_1_1_l_x___tmp_file.html#aeef32a442f8684de2d6e07abfee7d252',1,'LX_FileIO::LX_TmpFile::read()']]],
  ['readexactly',['readExactly',['../class_l_x___file_i_o_1_1_l_x___abstract_file.html#ac97bbaa4263e2713918eb859a855e651',1,'LX_FileIO::LX_AbstractFile::readExactly()'],['../class_l_x___file_i_o_1_1_l_x___file.html#a5c312039d8921ada81be214c47e29bfd',1,'LX_FileIO::LX_File::readExactly()'],['../class_l_x___file_i_o_1_1_l_x___tmp_file.html#a647b68971f70ca598463fa9c1782ff25',1,'LX_FileIO::LX_TmpFile::readExactly()']]],
  ['readtag',['readTag',['../classlibtagpp_1_1_tag.html#ac4663c68b2ff2c83727bc6da03449796',1,'libtagpp::Tag']]],
  ['recv',['recv',['../class_l_x___multithreading_1_1_l_x___channel.html#ab10c33b90d0f870f7ec397bdf2565b32',1,'LX_Multithreading::LX_Channel']]],
  ['removepanning',['removePanning',['../namespace_l_x___mixer.html#a0352610cf6e4d7f8f895b7e51ff530c2',1,'LX_Mixer::removePanning()'],['../namespace_l_x___mixer.html#a89efe12920b6a8e0843e62cc7fd384ed',1,'LX_Mixer::removePanning(int chan)']]],
  ['removewindow',['removeWindow',['../class_l_x___win_1_1_l_x___window_manager.html#a26cc99c9ccc41db4c1e0c4bc17ebe9f7',1,'LX_Win::LX_WindowManager']]],
  ['reservechannels',['reserveChannels',['../namespace_l_x___mixer.html#a24ee2160eb40c2babc8d9fbc5501ceda',1,'LX_Mixer']]],
  ['resetanimation',['resetAnimation',['../class_l_x___graphics_1_1_l_x___animated_sprite.html#a1b16d8ec8fae70cdfe00f282bdb551dc',1,'LX_Graphics::LX_AnimatedSprite']]],
  ['resetposition',['resetPosition',['../namespace_l_x___mixer.html#a44b4bec3385b9fd2a5488f2f2fe5d6f7',1,'LX_Mixer::resetPosition()'],['../namespace_l_x___mixer.html#ac049da751c65c83c17ccf396e47286ea',1,'LX_Mixer::resetPosition(int chan)']]],
  ['resume',['resume',['../namespace_l_x___mixer.html#a88c2d90eeaaf877df49f5358825e62a2',1,'LX_Mixer']]],
  ['reversestereo',['reverseStereo',['../namespace_l_x___mixer.html#a9330facd6fcd3fd1af3dbc427d680cc1',1,'LX_Mixer::reverseStereo(bool flip)'],['../namespace_l_x___mixer.html#a5dea6429cee328b5698e50b5287489ef',1,'LX_Mixer::reverseStereo(int chan, bool flip)']]],
  ['rumbleeffectinit',['rumbleEffectInit',['../class_l_x___device_1_1_l_x___haptic.html#aeb021fb6fa4a38f4de67151821b2db31',1,'LX_Device::LX_Haptic']]],
  ['rumbleeffectplay',['rumbleEffectPlay',['../class_l_x___device_1_1_l_x___haptic.html#a1a2bbcbf39d5584adb2e699aa7ea344c',1,'LX_Device::LX_Haptic::rumbleEffectPlay()'],['../class_l_x___device_1_1_l_x___haptic.html#a55cf35206848d3068d363d99ccd3000c',1,'LX_Device::LX_Haptic::rumbleEffectPlay(float strength, uint32_t length)']]],
  ['runeffect',['runEffect',['../class_l_x___device_1_1_l_x___haptic.html#afea24280820757e8407797b34c27c58c',1,'LX_Device::LX_Haptic']]]
];
