var searchData=
[
  ['r',['r',['../struct_l_x__gl_colour.html#ab9285afc64fbd3b92f722eb9d05d0675',1,'LX_glColour']]],
  ['radius',['radius',['../struct_l_x___physics_1_1_l_x___circle.html#aaa9e90268010fc1ddea47439b0f97ca9',1,'LX_Physics::LX_Circle']]]
];
