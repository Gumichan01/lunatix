var searchData=
[
  ['imgmetadata',['ImgMetaData',['../structlibtagpp_1_1_img_meta_data.html',1,'libtagpp']]],
  ['ioexception',['IOException',['../class_l_x___file_i_o_1_1_i_o_exception.html',1,'LX_FileIO']]]
];
