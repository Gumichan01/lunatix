var searchData=
[
  ['uid',['uid',['../struct_l_x___device_1_1_l_x___gamepad_info.html#aeeb2028977418cef859fd66cc8ec679c',1,'LX_Device::LX_GamepadInfo']]]
];
