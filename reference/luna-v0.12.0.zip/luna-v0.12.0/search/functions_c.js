var searchData=
[
  ['nbactiveparticles',['nbActiveParticles',['../class_l_x___particle_engine_1_1_l_x___particle_system.html#ad9f36808ec45062ba5b47da33c51ca34',1,'LX_ParticleEngine::LX_ParticleSystem']]],
  ['nbemptyparticles',['nbEmptyParticles',['../class_l_x___particle_engine_1_1_l_x___particle_system.html#a8b5dce47517a3d7eec9859ff4b053a8f',1,'LX_ParticleEngine::LX_ParticleSystem']]],
  ['nbtotalparticles',['nbTotalParticles',['../class_l_x___particle_engine_1_1_l_x___particle_system.html#aae204a06ff027de61e9ad65d0a8fffe6',1,'LX_ParticleEngine::LX_ParticleSystem']]],
  ['nbwindows',['nbWindows',['../class_l_x___win_1_1_l_x___window_manager.html#ae6439f6922cfe196f6235c2d8624a02e',1,'LX_Win::LX_WindowManager']]],
  ['neweffect',['newEffect',['../class_l_x___device_1_1_l_x___haptic.html#a60e57ebaf9163d213d3b1a85eab4e731',1,'LX_Device::LX_Haptic']]],
  ['normalize',['normalize',['../namespace_l_x___physics.html#a5392d9cef7ea4f13bd33d15f80733069',1,'LX_Physics']]],
  ['numberofdevices',['numberOfDevices',['../namespace_l_x___device.html#aa1f53457a99f79e69d3719e8def603db',1,'LX_Device']]],
  ['numberofedges',['numberOfEdges',['../class_l_x___physics_1_1_l_x___polygon.html#aee918ef4f7286e1cc01094fc1320a360',1,'LX_Physics::LX_Polygon']]],
  ['numberofeffects',['numberOfEffects',['../class_l_x___device_1_1_l_x___haptic.html#a79a1e278708340c8540e24723f85a726',1,'LX_Device::LX_Haptic']]],
  ['numberofhapticdevices',['numberOfHapticDevices',['../namespace_l_x___device.html#a19dd7f2f4014c485873c473de82e2026',1,'LX_Device']]]
];
