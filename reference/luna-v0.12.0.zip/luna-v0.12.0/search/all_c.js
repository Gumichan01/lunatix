var searchData=
[
  ['major',['major',['../struct_l_x___version_info_1_1_l_x___version.html#a6d46fde739a1ef756a5d23ac08916d62',1,'LX_VersionInfo::LX_Version']]],
  ['metadata',['metaData',['../class_l_x___mixer_1_1_l_x___music.html#a9a52fb95fc5bb4a93c461aa8fdbe4056',1,'LX_Mixer::LX_Music']]],
  ['minor',['minor',['../struct_l_x___version_info_1_1_l_x___version.html#a2e7dda243b964f917303a8e1d2f78d70',1,'LX_VersionInfo::LX_Version']]],
  ['mousecursordisplay',['mouseCursorDisplay',['../namespace_l_x___device.html#a3eb6327cb65bd2ebb388c1775e827cb0',1,'LX_Device']]],
  ['mouseishaptic',['mouseIsHaptic',['../namespace_l_x___device.html#a5de09978a94e54a37877618713d2fc76',1,'LX_Device']]],
  ['move',['move',['../class_l_x___physics_1_1_l_x___polygon.html#af8da2793a878cafb14383991f099bf5d',1,'LX_Physics::LX_Polygon::move(const float vx, const float vy) noexcept'],['../class_l_x___physics_1_1_l_x___polygon.html#a0042c2f3c99854f6bd45a2ee702d05d5',1,'LX_Physics::LX_Polygon::move(const LX_Vector2D &amp;v) noexcept']]],
  ['movecircle',['moveCircle',['../namespace_l_x___physics.html#ab0720967b150e3e92f9768d3e0c4a7c3',1,'LX_Physics::moveCircle(LX_Circle &amp;C, const int vx, const int vy) noexcept'],['../namespace_l_x___physics.html#a4ad89454b4aa266156a831c4795d8e9e',1,'LX_Physics::moveCircle(LX_Circle &amp;C, const LX_Vector2D &amp;v) noexcept']]],
  ['movecircleto',['moveCircleTo',['../namespace_l_x___physics.html#a1b8fa9852ccc454ab6636eda7b02b0f9',1,'LX_Physics::moveCircleTo(LX_Circle &amp;C, const int xpos, const int ypos) noexcept'],['../namespace_l_x___physics.html#a115680c0164aa5448c6f0f77465d614c',1,'LX_Physics::moveCircleTo(LX_Circle &amp;C, const LX_Point &amp;P) noexcept']]],
  ['movepoint',['movePoint',['../namespace_l_x___physics.html#a3b23481605e06d8fd65d81329fbb3295',1,'LX_Physics::movePoint(LX_Point &amp;P, const int vx, const int vy) noexcept'],['../namespace_l_x___physics.html#a08d2726120b4f74fb13287faa6d304a2',1,'LX_Physics::movePoint(LX_Point &amp;P, const LX_Vector2D &amp;v) noexcept']]],
  ['movepointto',['movePointTo',['../namespace_l_x___physics.html#a1c5988d0930e457e8a20e363647345d3',1,'LX_Physics']]],
  ['movepoly',['movePoly',['../namespace_l_x___physics.html#a4389b729dc0a8808b4cd5fa727cda8dd',1,'LX_Physics::movePoly(LX_Polygon &amp;poly, const float vx, const float vy) noexcept'],['../namespace_l_x___physics.html#ab6f00d13b9cfa48c1836b628dc3ac05e',1,'LX_Physics::movePoly(LX_Polygon &amp;poly, const LX_Vector2D &amp;v) noexcept']]],
  ['movepolyto',['movePolyTo',['../namespace_l_x___physics.html#a8bbd367b241e99e77fb8c83ca1cf76fe',1,'LX_Physics::movePolyTo(LX_Polygon &amp;poly, const int xpos, const int ypos)'],['../namespace_l_x___physics.html#a00b96fe51c410dd105b08888d373e7d0',1,'LX_Physics::movePolyTo(LX_Polygon &amp;poly, const LX_Point &amp;P)']]],
  ['moverect',['moveRect',['../namespace_l_x___physics.html#a3eaebf4fea86539437289505994aad93',1,'LX_Physics::moveRect(LX_AABB &amp;rect, const int vx, const int vy) noexcept'],['../namespace_l_x___physics.html#ab758ab015a4c76c14222dae60adc01f4',1,'LX_Physics::moveRect(LX_AABB &amp;rect, const LX_Vector2D &amp;v) noexcept']]],
  ['moverectto',['moveRectTo',['../namespace_l_x___physics.html#a66e144b5b33fa733526a5c93091ff5bc',1,'LX_Physics::moveRectTo(LX_AABB &amp;rect, const int xpos, const int ypos) noexcept'],['../namespace_l_x___physics.html#aff8614f5b5a3c493ed97cd925050d79f',1,'LX_Physics::moveRectTo(LX_AABB &amp;rect, const LX_Point &amp;P) noexcept']]],
  ['moveto',['moveTo',['../class_l_x___physics_1_1_l_x___polygon.html#af2c5ac5e12910b962bc4f10e7be02e8d',1,'LX_Physics::LX_Polygon::moveTo(int xpos, int ypos)'],['../class_l_x___physics_1_1_l_x___polygon.html#ae7603d37e3e6f6c49ba6d4a12777af8c',1,'LX_Physics::LX_Polygon::moveTo(const LX_Point &amp;p)']]],
  ['multiply',['multiply',['../namespace_l_x___physics.html#a8d435e49329172235f99555f9e24e32c',1,'LX_Physics']]],
  ['multithreading',['Multithreading',['../group___multithread.html',1,'']]]
];
