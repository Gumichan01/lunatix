var searchData=
[
  ['properties',['Properties',['../structlibtagpp_1_1_properties.html',1,'libtagpp']]]
];
