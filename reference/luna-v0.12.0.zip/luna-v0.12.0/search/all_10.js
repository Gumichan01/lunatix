var searchData=
[
  ['r',['r',['../struct_l_x__gl_colour.html#ab9285afc64fbd3b92f722eb9d05d0675',1,'LX_glColour']]],
  ['radius',['radius',['../struct_l_x___physics_1_1_l_x___circle.html#aaa9e90268010fc1ddea47439b0f97ca9',1,'LX_Physics::LX_Circle']]],
  ['read',['read',['../class_l_x___file_i_o_1_1_l_x___abstract_file.html#a61067d03795a15a9e66b5c336a479b21',1,'LX_FileIO::LX_AbstractFile::read()'],['../class_l_x___file_i_o_1_1_l_x___file.html#ad4c53be6b023c7cdbda38b0d0216671b',1,'LX_FileIO::LX_File::read()'],['../class_l_x___file_i_o_1_1_l_x___tmp_file.html#a714fd847e89202ce49d58866a6873528',1,'LX_FileIO::LX_TmpFile::read()']]],
  ['readexactly',['readExactly',['../class_l_x___file_i_o_1_1_l_x___abstract_file.html#a03d74ad4a6222d063a459f266b06ed7f',1,'LX_FileIO::LX_AbstractFile::readExactly()'],['../class_l_x___file_i_o_1_1_l_x___file.html#a763946bc228c7c989797a3e15163fca3',1,'LX_FileIO::LX_File::readExactly()'],['../class_l_x___file_i_o_1_1_l_x___tmp_file.html#a4812659cfc90e794cedb7c317a9c950c',1,'LX_FileIO::LX_TmpFile::readExactly()']]],
  ['readtag',['readTag',['../classlibtagpp_1_1_tag.html#ac4663c68b2ff2c83727bc6da03449796',1,'libtagpp::Tag']]],
  ['recv',['recv',['../class_l_x___multithreading_1_1_l_x___channel.html#ab10c33b90d0f870f7ec397bdf2565b32',1,'LX_Multithreading::LX_Channel']]],
  ['refresh_5frate',['refresh_rate',['../struct_l_x___system_info_1_1_l_x___display_mode.html#a1bcd047299a07537fd909dc333bd6588',1,'LX_SystemInfo::LX_DisplayMode']]],
  ['removepanning',['removePanning',['../namespace_l_x___mixer.html#aeee7ed8ed921b25ca0adc6d9d4044d89',1,'LX_Mixer::removePanning() noexcept'],['../namespace_l_x___mixer.html#a7755123c9f9e5e011413634848996826',1,'LX_Mixer::removePanning(int chan) noexcept']]],
  ['removewindow',['removeWindow',['../class_l_x___win_1_1_l_x___window_manager.html#a15f91b2414ce980fc041ee0bd94d2d26',1,'LX_Win::LX_WindowManager']]],
  ['reservechannels',['reserveChannels',['../namespace_l_x___mixer.html#a4e794aed8436b3d034bed02c05cc9e3d',1,'LX_Mixer']]],
  ['resetanimation',['resetAnimation',['../class_l_x___graphics_1_1_l_x___animated_sprite.html#a1d7b2c8b091f71941ffe25354e8f94b8',1,'LX_Graphics::LX_AnimatedSprite']]],
  ['resetposition',['resetPosition',['../namespace_l_x___mixer.html#ae9244d5dd4bd058f99dafd774802f446',1,'LX_Mixer::resetPosition() noexcept'],['../namespace_l_x___mixer.html#af9a319031e45dfee5f9260a36b918e02',1,'LX_Mixer::resetPosition(int chan) noexcept']]],
  ['resume',['resume',['../namespace_l_x___mixer.html#aaffb36d5e4659d994c94d030a529f22c',1,'LX_Mixer']]],
  ['rev_5fstereo',['rev_stereo',['../struct_l_x___mixer_1_1_l_x___mixer_effect.html#a3b51ab24b8e436d4e75007cd6af8f04c',1,'LX_Mixer::LX_MixerEffect']]],
  ['reversestereo',['reverseStereo',['../namespace_l_x___mixer.html#a88b88924bb50f75c800528ba97a87a54',1,'LX_Mixer::reverseStereo(bool flip) noexcept'],['../namespace_l_x___mixer.html#a0cf18b485d6e77d22a12371199ee87fe',1,'LX_Mixer::reverseStereo(int chan, bool flip) noexcept']]],
  ['rumbleeffectinit',['rumbleEffectInit',['../class_l_x___device_1_1_l_x___haptic.html#a49478ab52b02278064330ee619338905',1,'LX_Device::LX_Haptic']]],
  ['rumbleeffectplay',['rumbleEffectPlay',['../class_l_x___device_1_1_l_x___haptic.html#a4fb50851f8e3e094fde22925b59265fb',1,'LX_Device::LX_Haptic::rumbleEffectPlay() noexcept'],['../class_l_x___device_1_1_l_x___haptic.html#ab9292a25b6bd400f36af1616ca35a4f7',1,'LX_Device::LX_Haptic::rumbleEffectPlay(float strength, uint32_t length) noexcept']]],
  ['runeffect',['runEffect',['../class_l_x___device_1_1_l_x___haptic.html#a5879c34c4ab3edea2f3bc84cbbc11854',1,'LX_Device::LX_Haptic']]]
];
