var searchData=
[
  ['year',['year',['../classlibtagpp_1_1_tag.html#a2f1d9feebed9e19124c8a0d640a9c8d8',1,'libtagpp::Tag']]]
];
