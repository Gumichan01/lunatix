var searchData=
[
  ['major',['major',['../struct_l_x___version_info_1_1_l_x___version.html#a6d46fde739a1ef756a5d23ac08916d62',1,'LX_VersionInfo::LX_Version']]],
  ['minor',['minor',['../struct_l_x___version_info_1_1_l_x___version.html#a2e7dda243b964f917303a8e1d2f78d70',1,'LX_VersionInfo::LX_Version']]]
];
