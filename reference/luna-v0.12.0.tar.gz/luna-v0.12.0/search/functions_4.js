var searchData=
[
  ['effectsupported',['effectSupported',['../class_l_x___device_1_1_l_x___haptic.html#a47a28153814db1fbb859cfdd496c0013',1,'LX_Device::LX_Haptic']]],
  ['euclide_5fdistance',['euclide_distance',['../namespace_l_x___physics.html#ab77d45d1cc577cfada56e20ba4b96eae',1,'LX_Physics::euclide_distance(const int x1, const int y1, const int x2, const int y2) noexcept'],['../namespace_l_x___physics.html#a1fcff66c21261120fbb14bcc5504532a',1,'LX_Physics::euclide_distance(const LX_Point &amp;p1, const LX_Point &amp;p2) noexcept']]],
  ['euclide_5fsquare_5fdistance',['euclide_square_distance',['../namespace_l_x___physics.html#af631dadd13b021c7b90702aea5ca4c93',1,'LX_Physics::euclide_square_distance(const int x1, const int y1, const int x2, const int y2) noexcept'],['../namespace_l_x___physics.html#a154bd7a300a94616fe7d797749cd1ee8',1,'LX_Physics::euclide_square_distance(const LX_Point &amp;p1, const LX_Point &amp;p2) noexcept']]],
  ['eventloop',['eventLoop',['../class_l_x___text_1_1_l_x___text_input.html#a1ba2694463564cc90c2f1e023e4eb275',1,'LX_Text::LX_TextInput']]],
  ['expirechannel',['expireChannel',['../namespace_l_x___mixer.html#a49c69547be0c5184a17225241cd257d4',1,'LX_Mixer']]],
  ['extensionsupported',['extensionSupported',['../namespace_l_x___graphics_1_1_l_x___open_g_l.html#ace711b8b8766b9c56040baf824e8d149',1,'LX_Graphics::LX_OpenGL']]]
];
