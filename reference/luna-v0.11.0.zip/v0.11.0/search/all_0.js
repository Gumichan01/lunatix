var searchData=
[
  ['_5fimg_5foffset',['_img_offset',['../structlibtagpp_1_1_img_meta_data.html#a314d06c9419f3a74803aee7350b3454a',1,'libtagpp::ImgMetaData']]],
  ['_5fimg_5fsize',['_img_size',['../structlibtagpp_1_1_img_meta_data.html#a47fbe25e6048df4d0644d842e1adb87f',1,'libtagpp::ImgMetaData']]]
];
