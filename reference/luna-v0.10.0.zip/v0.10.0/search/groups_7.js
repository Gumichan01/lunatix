var searchData=
[
  ['physics',['Physics',['../group___physics.html',1,'']]]
];
