var searchData=
[
  ['file_20abstraction',['File abstraction',['../group___file.html',1,'']]]
];
